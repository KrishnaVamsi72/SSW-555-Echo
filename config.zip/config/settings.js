//YOU WILL NEED TO CHANGE THE DB NAME TO MATCH THE REQUIRED DB NAME IN THE ASSIGNMENT SPECS!!!


export const mongoConfig = {
  serverUrl: 'mongodb+srv://teamecho:echo%409908@agilecluster.krq8ocy.mongodb.net/',
  database: 'agile-team16' // Change 'YourDatabaseName' to your actual database name
};


